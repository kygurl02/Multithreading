/*
 * Multithreading Interface for the Internet Alarm Clock
 * This class only contains the visual for the clock
 */

package clock;

//import libraries
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Calendar;

/**
 *
 * @author Ky
 */
class Clock extends JFrame {
    
    //set by timer listener
    private JTextField timeField;
    
    //constructor
    public Clock() {
        //set characteristics of text field that shows the time
        timeField = new JTextField(5);
        timeField.setLayout(new FlowLayout());
        timeField.setFont(new Font("sansserif", Font.PLAIN, 60));
        timeField.setEditable(false);
        
        //make buttons for each setting
        JButton setClock = new JButton("Set Clock");
        JButton setAlarm = new JButton("Set Alarm");
        JButton update = new JButton("Update");
        JButton offAlarm = new JButton("Turn off Alarm");
        JButton snooze = new JButton("Snooze");
        
        //alarm icon
        ImageIcon alarmIcon = new ImageIcon("/Users/Ky/Documents/School/Computer Science/CMIS 495/MultithreadingInterface/src/clock/Time-Alarm-clock-icon.png", "alarm symbol");
        JLabel aIcon = new JLabel(alarmIcon);
        
        //Button panel
        JPanel buttons = new JPanel();
        buttons.setLayout(new FlowLayout());
        buttons.add(update);
        buttons.add(snooze);
        buttons.add(setAlarm);
        
        //Second Button panel
        JPanel buttons2 = new JPanel();
        buttons2.setLayout(new FlowLayout());
        buttons2.add(offAlarm);
        buttons2.add(setClock);
        
        //Button panel for all buttons
        JPanel buttonsAll = new JPanel();
        buttonsAll.setLayout(new GridLayout(2,1));
        buttonsAll.add(buttons);
        buttonsAll.add(buttons2);
        
        //Clock panel
        JPanel clock = new JPanel();
        clock.setLayout(new FlowLayout());
        clock.add(timeField);
        clock.add(aIcon);
        
        //Final panel
        JPanel interFace = new JPanel();
        interFace.setLayout(new GridLayout(2,1,0,0));
        interFace.add(clock);
        interFace.add(buttonsAll);
        //interFace.add(alarmSymbol);
        
        this.add(interFace);
        this.setTitle("Internet Alarm Clock");
        this.pack();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        
        //create time which calls action listener every second
        javax.swing.Timer t = new javax.swing.Timer(1000, new ClockListener());
        t.start();
        
    }

    class ClockListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            //when called, the current time will be
            //fetched and displayed
            Calendar now = Calendar.getInstance();
            int h = now.get(Calendar.HOUR_OF_DAY);
            int m = now.get(Calendar.MINUTE);
            int s = now.get(Calendar.SECOND);
            timeField.setText("" + h + ":" + m + ":" + s);
        }
    }
    public static void main(String[] args) {
        JFrame clock = new Clock();
        clock.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        clock.setVisible(true);
    }
    
}
